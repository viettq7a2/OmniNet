import express from 'express';
import net from 'node:net';
import dns from 'node:dns/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface PortCheckResult {
  port: number;
  service: string;
  open: boolean;
  latencyMs: number | null;
}

const SERVICE_MAP: Record<number, string> = {
  22: 'SSH',
  23: 'Telnet',
  53: 'DNS',
  80: 'HTTP',
  161: 'SNMP',
  179: 'BGP',
  443: 'HTTPS',
  3389: 'RDP',
  8080: 'HTTP-Alt',
  8443: 'HTTPS-Mgmt',
};

function checkTcpPort(host: string, port: number, timeoutMs = 1500): Promise<PortCheckResult> {
  return new Promise((resolve) => {
    const start = performance.now();
    const socket = new net.Socket();
    let settled = false;

    const finish = (open: boolean) => {
      if (settled) return;
      settled = true;
      const elapsed = open ? Math.max(1, Math.round(performance.now() - start)) : null;
      socket.destroy();
      resolve({
        port,
        service: SERVICE_MAP[port] || `TCP/${port}`,
        open,
        latencyMs: elapsed,
      });
    };

    socket.setTimeout(timeoutMs);
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));

    try {
      socket.connect(port, host);
    } catch {
      finish(false);
    }
  });
}

async function fetchHttpServerBanner(targetHost: string, useHttps: boolean): Promise<string | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 1800);
  try {
    const protocol = useHttps ? 'https' : 'http';
    const response = await fetch(`${protocol}://${targetHost}`, {
      method: 'HEAD',
      redirect: 'manual',
      signal: controller.signal,
    });
    const serverHeader = response.headers.get('server') || response.headers.get('x-powered-by');
    return serverHeader ? `${serverHeader} (HTTP ${response.status})` : `HTTP ${response.status}`;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function inferVendorAndRole(hostname: string, banner: string | null, openPorts: number[]): {
  vendor: string;
  role: string;
  model: string;
  osVersion: string;
} {
  const combined = `${hostname} ${banner || ''}`.toLowerCase();
  if (combined.includes('cloudflare')) {
    return { vendor: 'Linux / Edge', role: 'Firewall', model: 'Cloudflare Edge Anycast', osVersion: 'EdgeOS TLS 1.3' };
  }
  if (combined.includes('forti')) {
    return { vendor: 'Fortinet', role: 'Firewall', model: 'FortiGate NGFW', osVersion: 'FortiOS 7.4' };
  }
  if (combined.includes('palo') || combined.includes('pan-os')) {
    return { vendor: 'Palo Alto', role: 'Firewall', model: 'PA-Series NGFW', osVersion: 'PAN-OS 11.1' };
  }
  if (combined.includes('cisco') || combined.includes('ios')) {
    return { vendor: 'Cisco', role: 'Router', model: 'Catalyst Edge Platform', osVersion: 'IOS-XE 17.9' };
  }
  if (combined.includes('juniper') || combined.includes('junos')) {
    return { vendor: 'Juniper', role: 'Router', model: 'MX Series Edge', osVersion: 'Junos 23.2' };
  }
  if (combined.includes('mikrotik')) {
    return { vendor: 'MikroTik', role: 'Router', model: 'Cloud Core Router', osVersion: 'RouterOS 7.14' };
  }
  if (openPorts.includes(53) && !openPorts.includes(22)) {
    return { vendor: 'Linux / Server', role: 'Server', model: 'Enterprise DNS Resolver', osVersion: 'Linux Kernel 6.8' };
  }
  if (openPorts.includes(179)) {
    return { vendor: 'Cisco', role: 'Router', model: 'BGP Core Router', osVersion: 'IOS-XR / BGP4' };
  }
  if (openPorts.includes(8443) || (openPorts.includes(443) && openPorts.includes(22))) {
    return { vendor: 'Fortinet', role: 'Firewall', model: 'Enterprise Perimeter Gateway', osVersion: 'Appliance OS' };
  }
  return {
    vendor: 'Linux / Server',
    role: 'Server',
    model: banner ? `Web/App Host (${banner.slice(0, 28)})` : 'Discovered TCP Network Node',
    osVersion: 'Linux / POSIX TCP Stack',
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  app.post('/api/probe', async (req, res) => {
    try {
      const rawTarget = String(req.body?.target || '').trim();
      if (!rawTarget) {
        res.status(400).json({ error: 'Target hostname or IPv4 address is required.' });
        return;
      }

      const sanitizedTarget = rawTarget
        .replace(/^https?:\/\//i, '')
        .split('/')[0]
        .split(':')[0]
        .trim();

      if (!sanitizedTarget || sanitizedTarget.length > 253 || /[^a-zA-Z0-9.-]/.test(sanitizedTarget)) {
        res.status(400).json({ error: 'Invalid hostname or IPv4 address format.' });
        return;
      }

      const requestedPorts: number[] = Array.isArray(req.body?.ports)
        ? req.body.ports
            .map((p: unknown) => Number(p))
            .filter((p: number) => Number.isInteger(p) && p >= 1 && p <= 65535)
            .slice(0, 8)
        : [22, 53, 80, 443, 8443];

      const portsToScan = requestedPorts.length > 0 ? requestedPorts : [22, 53, 80, 443];

      let resolvedIp = sanitizedTarget;
      let resolvedHostname = sanitizedTarget;

      try {
        const lookup = await dns.lookup(sanitizedTarget, { family: 4 });
        resolvedIp = lookup.address;
      } catch {
        // Target might be unreachable or unresolvable
      }

      if (/^\d{1,3}(\.\d{1,3}){3}$/.test(sanitizedTarget)) {
        try {
          const ptrs = await dns.reverse(resolvedIp);
          if (ptrs.length > 0) {
            resolvedHostname = ptrs[0];
          }
        } catch {
          resolvedHostname = `node-${resolvedIp.replace(/\./g, '-')}.net.local`;
        }
      }

      const portChecks = await Promise.all(portsToScan.map((p) => checkTcpPort(resolvedIp, p, 1500)));
      const openResults = portChecks.filter((r) => r.open);
      const openPorts = openResults.map((r) => r.port);

      let banner: string | null = null;
      if (openPorts.includes(443)) {
        banner = await fetchHttpServerBanner(sanitizedTarget, true);
      } else if (openPorts.includes(80)) {
        banner = await fetchHttpServerBanner(sanitizedTarget, false);
      }

      const latencies = openResults
        .map((r) => r.latencyMs)
        .filter((v): v is number => typeof v === 'number');

      const avgLatencyMs =
        latencies.length > 0
          ? Math.round(latencies.reduce((acc, n) => acc + n, 0) / latencies.length)
          : 0;

      const reachable = openPorts.length > 0;
      const inferred = inferVendorAndRole(resolvedHostname, banner, openPorts);

      res.json({
        target: sanitizedTarget,
        ip: resolvedIp,
        hostname: resolvedHostname,
        reachable,
        avgLatencyMs,
        openPorts,
        portChecks,
        banner,
        inferred,
        probedAt: new Date().toISOString(),
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Probe request failed';
      res.status(500).json({ error: msg });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NetVista Enterprise server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
