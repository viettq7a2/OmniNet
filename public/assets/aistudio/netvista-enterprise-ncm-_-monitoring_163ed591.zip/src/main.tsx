import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

try {
  const desc =
    Object.getOwnPropertyDescriptor(window, 'fetch') ||
    Object.getOwnPropertyDescriptor(Window.prototype, 'fetch');
  if (desc && typeof desc.get === 'function' && typeof desc.set !== 'function' && desc.configurable !== false) {
    let activeFetch = desc.get.call(window);
    Object.defineProperty(window, 'fetch', {
      configurable: true,
      enumerable: desc.enumerable !== false,
      get: () => activeFetch,
      set: (next: typeof window.fetch) => {
        if (typeof next === 'function') {
          activeFetch = next;
        }
      },
    });
  }
} catch {
  // Ignore if locked by browser environment
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

